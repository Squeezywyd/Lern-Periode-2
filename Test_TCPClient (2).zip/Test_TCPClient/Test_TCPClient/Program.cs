﻿using System;
using System.Text;
using SimpleTCP;

namespace TestTCPClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new SimpleTcpClient();
            client.StringEncoder = Encoding.UTF8;

            client.DataReceived += (sender, e) =>
            {
                var receivedMessage = e.MessageString;
                Console.WriteLine($"Received message from server: \"{receivedMessage}\".");
            };

            client.Connect("127.0.0.1", 5000);

            Console.WriteLine("Enter a message to send to the server (type 'exit' to quit):");

            while (true)
            {
                string input = Console.ReadLine();

                if (input.ToLower() == "exit")
                {
                    break;
                }

                client.WriteLine(input);
            }

            client.Disconnect();

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}
