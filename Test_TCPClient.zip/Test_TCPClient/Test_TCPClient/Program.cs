﻿using System;
using System.Text;
using SimpleTCP;

namespace TestTCPClient
{
    class program
    {

        static void Main(string[] args)
        {
            var client = new SimpleTcpClient();

            client.DataReceived += (sender, e) =>
            {
                var msg = Encoding.UTF8.GetString(e.Data);
                Console.WriteLine($"Received message: \"{msg}\".");
            };

            client.Connect("127.0.0.1", 5000);

            client.Write(Encoding.UTF8.GetBytes("Hello!"));

            Console.ReadLine();

        }
    }
}