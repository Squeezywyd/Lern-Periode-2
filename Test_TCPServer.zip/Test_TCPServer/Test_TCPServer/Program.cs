﻿using System;
using System.Text;
using SimpleTCP;




namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            var server = new SimpleTcpServer();
            
            server.ClientConnected += (sender, e) =>
            Console.WriteLine($"Client ({e.Client.RemoteEndPoint}) connected!");

            server.ClientDisconnected += (sender, e) =>
            Console.WriteLine($"Client ({e.Client.RemoteEndPoint}) disconnected!");

            server.DataReceived += (sender, e) =>
            {
                var ep = e.TcpClient.Client.RemoteEndPoint;
                var msg = Encoding.UTF8.GetString(e.Data);
                Console.WriteLine($"Received message from {ep}: \"{msg}\".");
                e.Reply(Encoding.UTF8.GetBytes("Hello back!"));
            };

            server.Start(5000);

            server.Broadcast(Encoding.UTF8.GetBytes("Message to everyone!"));

            Console.ReadLine();


        }
    }

}
